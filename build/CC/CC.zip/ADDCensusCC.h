#pragma once
#include "../CommFunc.h"
#include "../CCMethod.h"

#define CENCUS_WND 9
#define CENCUS_BIT 80
#define W1 0.25
#define t1 0.35
#define t2 0.65

class ADDCensusCC :
	public CCMethod
{
public:
	ADDCensusCC(void)
	{
		printf("\n\t\tADDCensus for Cost Computation");
	}
	~ADDCensusCC(void){}
public:
	void buildCV(const Mat& lImg, const Mat& rImg, const int maxDis, Mat* costVol);
#ifdef COMPUTE_RIGHT
	void buildRightCV(const Mat& lImg, const Mat& rImg, const int maxDis, Mat* rCostVol);
#endif
};
